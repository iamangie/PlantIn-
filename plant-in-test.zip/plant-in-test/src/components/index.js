export { default as Footer } from "./shared/Footer/Footer";
export { default as Header } from "./shared/Header/Header";
export { default as Main } from "./Main/Main";
